//xls package use to parse the 97 -2004 microsoft xls file(".xls" suffix, NOT ".xlsx" suffix )
//
//there are some example in godoc, please follow them.
package xls
