package xls

type SstInfo struct {
	Total uint32
	Count uint32
}
